create database zomato;
use zomato;
select database();
show databases;