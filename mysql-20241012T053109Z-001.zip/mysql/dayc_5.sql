create database city;
use city;
create table city_people(
people_id int primary key auto_increment,people_name varchar(70) not null,people_email varchar(80)unique)
auto_increment=101;
insert into city_people values(default,'amit','amit@123');


set sql_safe_updates=0;
select*from city_people;
update city_people set people_email='amit@12'
where people_name='amit';
delete from city_people where people_email='amit@12';