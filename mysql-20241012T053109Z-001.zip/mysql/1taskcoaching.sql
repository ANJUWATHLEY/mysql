create database lab;
use lab;
create table lab(user_id int ,firstname varchar(50),lastname varchar(50),
username varchar(30), followers_count int ,following_count int);

 create table user( user_name varchar(30), user_password int, user_id int) ;
drop table user;
drop database lab;
show databases;