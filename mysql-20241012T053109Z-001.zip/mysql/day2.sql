/*day2*/
create database University;
use University;
 create table student(s_name varchar(30), s_id int,s_email varchar(30));
 /* for structure*/
 desc student;
 show columns from student;
 /*insert value for raw*/
 insert into student values( "harsha",010876511,"harsha@21");
 select*from student;
 insert into  student(s_name,s_id) values("uama",12234);
 create table student_copy as select*from student;
 select*from student_copy;
 create table temp like student;
 desc temp;