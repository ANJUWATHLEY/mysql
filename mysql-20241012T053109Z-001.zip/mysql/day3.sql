/*day 3*/
create database bank;
use bank;
create table cus(account_number int, e_mail varchar(34), b_name varchar(40));
insert into cus values(0198777777,"an@123","Rakhi");
select * from cus;
create table player(p_name varchar(38),score int default 0);
insert into player(p_name) values('DHONI');
select*from player;
insert into player values ("virat kohali",40),("pawan",30);
drop table cus;
create table product(p_id int unique not null,p_name varchar(36) unique not null) ;
desc product;
insert into product values(1,"rad");
select *from product;