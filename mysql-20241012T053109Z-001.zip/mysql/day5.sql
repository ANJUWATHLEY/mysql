create database datalab;
use datalab;
create table  datalab ( t_name varchar(30) not null,s_id int unique,r_no int unique);

insert into  datalab values("kunal",89,80),("raja",41,3);

drop table datalab;
select *from datalab;
show tables;