
use insta;
create table worker( user_name varchar(30) not null,password int primary key auto_increment, fake_id  int  unique) auto_increment=101;

insert into worker(user_name , password)values( "raja",default);

select*from worker;
drop table instadata;
desc insta;
show tables;
show databases;
