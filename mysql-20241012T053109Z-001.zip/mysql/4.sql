create table company(pl_id int primary key auto_increment , pl_name varchar(70), score int default 0)auto_increment=201;

insert into company values(8,'nnii',97);
/* its have a five cunstraint ,unique,not null,auto_increment,default*/
select*from company;
set sql_safe_updates=0;
update company set pl_name ='nniipuaa';
drop table kii;
