create  database instadata;
use instadata;
create table instadata( user_name varchar(30),password int not null, fake_id int unique);

insert into instadata (user_name , password)values( "kunal",7645);

select*from instadata;
drop table instadata;

show tables;
show databases;
